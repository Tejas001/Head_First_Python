from distutils.core import setup

setup(
    name = 'loopnet',
    version = '1.0.3',
    py_modules = ['loopnet'],
    author = 'TejasC',
    author_email = 'tejas.chougule1994@gmail.com',
    # url = 'http://www.headfirstlabs.com',
    description = 'A simple printer of nested lists',
)